<?php

use App\Http\Controllers\AttandanceController;
use App\Http\Controllers\DashboardController;
use Illuminate\Routing\Controllers\Middleware;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;

// App\Http\Controllers\DashboardController ;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('dashboard');
// });

Route::group(['Middleware' =>['auth', 'varified']], function () {
});

Route::get('employee',[DashboardController::class,'employee']);
Route::get('adminuser',[DashboardController::class,'Admin_user']);

Route::get('login',[LoginController::class,'login']);
Route::post('login',[LoginController::class,'login_user']);

// Route::get('login',[loginController::class,'login_user']);
Route::get('register',[LoginController::class,'register']);
Route::post('register',[LoginController::class,'register_user']);
Route::get('logout',[LoginController::class,'logout']);
// Attandance-----//
Route::get('status',[AttandanceController::class,'Attandance']);




Route::get('forgetpassword',[LoginController::class,'forgetpassword']);
Route::post('forgetpassword',[LoginController::class,'forget_password']);
Route::get('reset',[LoginController::class,'reset']);
Route::post('reset',[LoginController::class,'reset_pas']);