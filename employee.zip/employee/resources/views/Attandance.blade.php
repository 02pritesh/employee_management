@extends('layouts.main')

@section('main-section')
<div class="container">
              <table class="table">
              <thead>
                        <tr class="alert alert-info">

                  <th> #</th>
                  <th> name </th>
                  <th> User_id</th>
        
                  <th> Status </th>
          
                  <th> Action </th>

                </tr>
              </thead>
              <tbody>
                @php
                $i = 1;
                @endphp
                @foreach ($data as $emp) 
                <tr>
                <td >{{$i++}}</td>
                <td >{{$emp->name}}</td>
                <td>{{$emp->user_id}}</td>
           
                <td>
              
                     {{$emp->status}}
</td>
        
          <td> <a href="EditBot/{{ $emp->id}}" class="btn btn-success">edit</a>
                
              </tr>
                @endforeach
               
              </tbody>
              </table>


@endsection