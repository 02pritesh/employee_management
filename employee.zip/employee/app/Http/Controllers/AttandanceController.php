<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\forget;
use App\Models\User;
use Illuminate\Support\facades\Auth;

use Session;
use Validator,Redirect,Response;
class AttandanceController extends Controller
{
     public function status(){
        return forget::all();
        
     }
     public function status_attan(Request $request){
        $validator=Validator::make($request->all(),[
            'user_id' => 'required',
            'status' => 'required|in:present',
        ]);

        $user  = User::find($request->user_id);
        // $user_id = $user->id;

        

        
        $forget = new forget();
        $forget->user_id =$request['user_id'];
        $forget->user_id = Auth::user()->id;

        $forget->status =$request['status'];
        $request= $forget->save();
        return response()->json($request);

        if($request){
            return response()->json('success');
           }else{
            return back()-> with('fail','please try again');
           }
       }
               public function Attandance(){
                $data = forget::get();
            
                // dd($data);
                return view('Attandance',compact('data'));
            }
        }
