<?php

namespace App\Http\Controllers;


use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Carbon;
use Illuminate\Support\facades\Auth;

use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;

use  App\Models\User;
use App\Models\forget;
use Illuminate\Support\facades\Hash;
use Session;
use Validator,Redirect,Response;



class LoginController extends Controller
{
    
    public function login(){
        return User::all();
        // return view('login');
    }

      public function login_user(Request $request){
            $validator=Validator::make($request->all(),[
            'email'=>'required',
            'password'=>'required',
        ]);
      
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }
       
      
      
          $user = User::where('email',$request->email)->first();
       
          if($user){
            if(Hash::check($request->password , $user->password)){
                if($user->user_type == 'admin'){
              
                return response()->json(['login'=>' admin login succefully' ],200);

               }else{
               // $request->Session()->put('loginId', $user);
               return response()->json(['login' =>'user login succefully'] ,200);

              }
           }else{
            return response()->json(['fail'=> 'this password is not valid'],400);
          }
          } 
          else{
            return response()->json(['fail'=> 'this email is not valid'],400);
          }
        
        }
     



        public function register(){
            return view('Register');
        }
        public function register_user(Request $request){
    
            $request->validate([
                'name' =>'required',
                'email'=> 'required',
                'password'=> 'required|min:5|max:8',


            ]);
                // -----save data in database----->
            $User = new User();
            $User->name=$request['name'];
            $User->Department=$request['Department'];
            $User->city=$request['city'];

            $User->email=$request['email'];
            $User->password = Hash::make($request['password']);

        
            $req = $User->save();
            if($req){
            return redirect('/login')-> with('success', 'you have registerd succefully');
            }else{
            return back()-> with('fail','please try again');
            }
        
    }











        public function forgetpassword(){
            return view('forgetpassword');
        }

        public function forget_password(Request $request){
            $request->validate([
                'email'=> 'required|exists:users',
            ]); 

             
            $user = User::where('email',$request->email)->first();
             
            if($user){
            $token = Str::random(60);
            $domain = Url::to('/');
            $url = $domain.'reset-password?token'.$token;
            $data['url']= $url;
            $data['email']= $request->email;
            $data['title'] = 'password reset';
            $data['body']= 'please click on below link';

            Mail::send('forgetmail',['data'=>$data ],function($message)use($data){
            $message->to($data['email'])->subject($data['title']);
            } );
            //   $m = "mail send";
            //   return $m;
            $datatime = Carbon::now()->format('y-m-d H:i:s');
            forget::updateOrCreate(
            ['email'=>$request->email],
            [
                'email'=>$request->email,
                'token' =>$request->token,
                'created_at'=>$datatime
            ]
            );
            return back()->with('success mail send');
        
            }else{
                return back()->with('not valid');
            }
        
        
    
    

}
        

    

        public function logout(Request $request ) {
            $request->Session()->forget('loginId');
            return redirect('/login')->with('success' , "logout successfully");
        // }else{
        }



        public function reset(){
            return User::all();
        }
      
       public function resetPass(Request $request){
        $validator=Validator::make($request->all(),[
            'old_password'        =>'required',
            'new_password'         =>'required',
        
         ]);
        $user  = User::find($request->id);

        $user_pass = $user->password;
        
        if(Hash::check($request->old_password, $user_pass)){
           
            $user->password = Hash::make($request->new_password);
            $user->save();

            return response()->json(['data' => $user, 'pass' => $user_pass]);

        }else{
            
            return response()->json(['data'=> false]);
        }

       }

       public function createPass(Request $request){
            $pass = Hash::make($request->pass);
            return response()->json(['data' => $pass ]);
       }






    }

    







