<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function admin_user(){
        
        if (!session()->has('loginId')) {
            return redirect('login');
          }else{
              return view('Dashboard');
          }
    }
    public function employee(){
        
        // if (!session()->has('loginId')) {
        //     return redirect('login');
        //   }else{
              return view('employee');
          }
    
}
